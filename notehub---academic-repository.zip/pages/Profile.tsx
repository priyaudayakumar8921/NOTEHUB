
import React from 'react';
import { useAuth } from '../context/AuthContext';
import { User, Mail, Shield, Calendar, Settings, FileText, Download, Star } from 'lucide-react';

export const Profile: React.FC = () => {
  const { profile, user } = useAuth();

  return (
    <div className="max-w-5xl mx-auto px-4 py-16 bg-white dark:bg-black min-h-screen">
      <div className="relative mb-20">
        <div className="h-64 bg-yellow-400 rounded-[3rem] overflow-hidden shadow-2xl relative">
          <div className="absolute inset-0 bg-black/5 opacity-50 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-white to-transparent"></div>
          <div className="absolute top-10 right-10 text-black/10">
            <Shield className="w-64 h-64 rotate-12" />
          </div>
        </div>
        
        <div className="absolute -bottom-10 left-12 flex items-end gap-10">
          <div className="w-40 h-40 rounded-[2.5rem] bg-white dark:bg-black p-2 border-8 border-white dark:border-black shadow-2xl">
            <div className="w-full h-full rounded-[1.8rem] bg-black dark:bg-yellow-400 flex items-center justify-center">
              <User className="w-20 h-20 text-white dark:text-black" />
            </div>
          </div>
          <div className="mb-6">
            <h1 className="text-5xl font-black text-black dark:text-white tracking-tighter uppercase leading-none mb-4">{profile?.name}</h1>
            <p className="px-5 py-1.5 bg-black dark:bg-yellow-400 text-white dark:text-black rounded-full text-[10px] font-black uppercase tracking-widest inline-block shadow-xl">
              {profile?.role === 'admin' ? 'System Administrator' : 'Archive Contributor'}
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 pt-16">
        <div className="lg:col-span-4 space-y-8">
          <div className="bg-zinc-50 dark:bg-zinc-900 rounded-[3rem] border border-zinc-200 dark:border-zinc-800 p-10 shadow-xl">
            <h3 className="text-[10px] font-black text-zinc-400 uppercase tracking-[0.4em] mb-10 flex items-center gap-4">
              <Settings className="w-5 h-5 text-yellow-500" /> Identity
            </h3>
            <div className="space-y-8">
              <div className="flex items-center gap-5">
                <div className="p-3 bg-white dark:bg-black rounded-xl border border-zinc-100 dark:border-zinc-800 shadow-sm">
                  <Mail className="w-5 h-5 text-zinc-400" />
                </div>
                <div>
                  <p className="text-[10px] uppercase font-black text-zinc-400 tracking-widest mb-1">Email</p>
                  <p className="text-sm font-black text-black dark:text-white truncate max-w-[200px]">{profile?.email}</p>
                </div>
              </div>
              <div className="flex items-center gap-5">
                <div className="p-3 bg-white dark:bg-black rounded-xl border border-zinc-100 dark:border-zinc-800 shadow-sm">
                  <Shield className="w-5 h-5 text-zinc-400" />
                </div>
                <div>
                  <p className="text-[10px] uppercase font-black text-zinc-400 tracking-widest mb-1">Access</p>
                  <p className="text-sm font-black text-yellow-600 dark:text-yellow-400 uppercase">{profile?.role}</p>
                </div>
              </div>
              <div className="flex items-center gap-5">
                <div className="p-3 bg-white dark:bg-black rounded-xl border border-zinc-100 dark:border-zinc-800 shadow-sm">
                  <Calendar className="w-5 h-5 text-zinc-400" />
                </div>
                <div>
                  <p className="text-[10px] uppercase font-black text-zinc-400 tracking-widest mb-1">Enlisted</p>
                  <p className="text-sm font-black text-black dark:text-white">
                    {profile?.created_at ? new Date(profile.created_at).toLocaleDateString() : 'N/A'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-8 space-y-10">
           <div className="bg-zinc-50 dark:bg-zinc-950 rounded-[4rem] border border-zinc-200 dark:border-zinc-900 p-12 lg:p-16 shadow-2xl">
              <h2 className="text-4xl font-black uppercase tracking-tighter mb-4">Contribution Log</h2>
              <p className="text-zinc-500 dark:text-zinc-500 font-bold uppercase tracking-widest text-[10px] mb-12">Performance analysis & global ranking.</p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                <div className="p-10 rounded-[3rem] bg-white dark:bg-zinc-900/50 border border-zinc-100 dark:border-zinc-800 flex flex-col items-center text-center group hover:border-yellow-400 transition-all">
                  <div className="w-16 h-16 rounded-[1.5rem] bg-black dark:bg-yellow-400 text-white dark:text-black flex items-center justify-center mb-6 shadow-xl group-hover:scale-110 transition-transform">
                    <FileText className="w-8 h-8" />
                  </div>
                  <div className="text-3xl font-black mb-2 uppercase tracking-tighter">ARCHIVE</div>
                  <div className="text-[10px] text-zinc-400 uppercase font-black tracking-widest">Active Data Feed</div>
                </div>
                <div className="p-10 rounded-[3rem] bg-white dark:bg-zinc-900/50 border border-zinc-100 dark:border-zinc-800 flex flex-col items-center text-center group hover:border-yellow-400 transition-all">
                  <div className="w-16 h-16 rounded-[1.5rem] bg-black dark:bg-yellow-400 text-white dark:text-black flex items-center justify-center mb-6 shadow-xl group-hover:scale-110 transition-transform">
                    <Star className="w-8 h-8" />
                  </div>
                  <div className="text-3xl font-black mb-2 uppercase tracking-tighter">LEGEND</div>
                  <div className="text-[10px] text-zinc-400 uppercase font-black tracking-widest">Reputation Rank</div>
                </div>
              </div>

              <div className="mt-16 p-10 rounded-[3rem] bg-yellow-400 dark:bg-yellow-400/5 border border-yellow-400/20 text-black dark:text-yellow-400">
                <h4 className="font-black text-xl uppercase tracking-tighter flex items-center gap-4 mb-4">
                   <Shield className="w-6 h-6" /> System Policy
                </h4>
                <p className="text-sm font-bold leading-relaxed opacity-80 uppercase tracking-tight">
                  Archive data is encrypted at rest. Contributor identities are verified by the central command to maintain high-fidelity academic integrity across the KTU network.
                </p>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};
