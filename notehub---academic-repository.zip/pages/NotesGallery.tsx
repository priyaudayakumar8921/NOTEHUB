
import React, { useEffect, useState, useCallback } from 'react';
import { supabase, Note, SchemeType } from '../lib/supabase';
import { 
  Search, 
  Book, 
  Download, 
  Star, 
  FileText, 
  Loader2,
  Inbox,
  LayoutGrid,
  List,
  X,
  ChevronRight,
  Info,
  ShieldCheck,
  User as UserIcon,
  Layers
} from 'lucide-react';

export const NotesGallery: React.FC = () => {
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [semesterFilter, setSemesterFilter] = useState<string>('');
  const [schemeFilter, setSchemeFilter] = useState<string>('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);

  useEffect(() => {
    fetchNotes();
  }, [semesterFilter, schemeFilter]);

  const fetchNotes = async () => {
    setLoading(true);
    let query = supabase
      .from('notes')
      .select('*, profiles(name)')
      .eq('verified', true)
      .order('created_at', { ascending: false });

    if (semesterFilter) query = query.eq('semester', parseInt(semesterFilter));
    if (schemeFilter) query = query.eq('scheme', schemeFilter);

    const { data, error } = await query;
    if (!error) setNotes(data || []);
    setLoading(false);
  };

  const filteredNotes = notes.filter(n => 
    n.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    n.subject.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getRelatedNotes = (currentNote: Note) => {
    return notes
      .filter(n => n.id !== currentNote.id && n.subject === currentNote.subject)
      .slice(0, 3);
  };

  const handleCloseModal = useCallback(() => {
    setSelectedNote(null);
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 py-16 relative">
      <div className="mb-12">
        <h1 className="text-5xl md:text-7xl font-black mb-4 tracking-tighter uppercase">Archives</h1>
        <p className="text-zinc-500 dark:text-zinc-400 font-bold uppercase tracking-widest text-xs">Verified academic resources for KTU CS Students</p>
      </div>

      {/* Filter System */}
      <div className="bg-zinc-50 dark:bg-zinc-900/50 p-6 rounded-[2rem] border border-zinc-200 dark:border-zinc-800 mb-12 flex flex-col lg:flex-row gap-4">
        <div className="flex-grow relative">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
          <input 
            type="text" 
            placeholder="Search keywords..." 
            className="w-full pl-14 pr-6 py-4 bg-white dark:bg-black border border-zinc-200 dark:border-zinc-800 rounded-2xl outline-none focus:ring-4 focus:ring-yellow-400/20 transition-all font-bold text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex flex-wrap items-center gap-4">
          <select 
            className="px-6 py-4 bg-white dark:bg-black border border-zinc-200 dark:border-zinc-800 rounded-2xl outline-none focus:ring-4 focus:ring-yellow-400/20 text-sm font-black uppercase tracking-widest"
            value={schemeFilter}
            onChange={(e) => setSchemeFilter(e.target.value)}
          >
            <option value="">All Schemes</option>
            <option value="2019">2019 Scheme</option>
            <option value="2024">2024 Scheme</option>
          </select>

          <select 
            className="px-6 py-4 bg-white dark:bg-black border border-zinc-200 dark:border-zinc-800 rounded-2xl outline-none focus:ring-4 focus:ring-yellow-400/20 text-sm font-black uppercase tracking-widest"
            value={semesterFilter}
            onChange={(e) => setSemesterFilter(e.target.value)}
          >
            <option value="">All Semesters</option>
            {[1, 2, 3, 4, 5, 6, 7, 8].map(s => <option key={s} value={s}>Sem {s}</option>)}
          </select>
          
          <div className="flex items-center gap-1 bg-white dark:bg-black p-1.5 rounded-2xl border border-zinc-200 dark:border-zinc-800">
            <button 
              onClick={() => setViewMode('grid')}
              className={`p-3 rounded-xl transition-all ${viewMode === 'grid' ? 'bg-yellow-400 text-black shadow-lg' : 'text-zinc-400 hover:text-black dark:hover:text-white'}`}
            >
              <LayoutGrid className="w-5 h-5" />
            </button>
            <button 
              onClick={() => setViewMode('list')}
              className={`p-3 rounded-xl transition-all ${viewMode === 'list' ? 'bg-yellow-400 text-black shadow-lg' : 'text-zinc-400 hover:text-black dark:hover:text-white'}`}
            >
              <List className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-40">
          <Loader2 className="w-16 h-16 text-yellow-400 animate-spin mb-6" />
          <p className="text-zinc-400 font-black uppercase tracking-[0.3em] text-[10px]">Accessing Data...</p>
        </div>
      ) : filteredNotes.length > 0 ? (
        viewMode === 'grid' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 animate-in fade-in slide-in-from-bottom-8 duration-700">
            {filteredNotes.map((note) => (
              <div 
                key={note.id} 
                onClick={() => setSelectedNote(note)}
                className="group cursor-pointer bg-white dark:bg-zinc-950 rounded-[2.5rem] border-2 border-zinc-100 dark:border-zinc-900 overflow-hidden hover:border-yellow-400 transition-all flex flex-col hover:shadow-2xl hover:shadow-yellow-400/5"
              >
                <div className="h-44 bg-zinc-50 dark:bg-zinc-900 relative flex items-center justify-center border-b border-zinc-100 dark:border-zinc-900">
                  <div className="absolute inset-0 opacity-5 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-yellow-400 to-transparent"></div>
                  <Book className="w-16 h-16 text-zinc-200 dark:text-zinc-800 group-hover:scale-110 transition-transform duration-500 group-hover:text-yellow-400" />
                  <div className="absolute top-6 right-6 flex gap-2">
                    <span className="px-3 py-1 bg-zinc-900 text-white dark:bg-zinc-800 text-[10px] font-black uppercase tracking-widest rounded-full">
                      {note.scheme}
                    </span>
                    <span className="px-3 py-1 bg-yellow-400 text-black text-[10px] font-black uppercase tracking-widest rounded-full shadow-xl">
                      SEM {note.semester}
                    </span>
                  </div>
                </div>
                <div className="p-8 flex-grow flex flex-col">
                  <h3 className="text-2xl font-black line-clamp-2 leading-none mb-4 group-hover:text-yellow-500 transition-colors uppercase tracking-tighter">{note.title}</h3>
                  <p className="text-zinc-400 text-[10px] mb-8 font-black uppercase tracking-[0.2em]">{note.subject}</p>
                  
                  <div className="mt-auto flex items-center justify-between pt-8 border-t border-zinc-100 dark:border-zinc-900">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center border border-zinc-200 dark:border-zinc-700">
                        <UserIcon className="w-4 h-4 text-zinc-400" />
                      </div>
                      <div className="text-[10px] uppercase font-black text-zinc-500">
                        <p>{(note as any).profiles?.name || 'Anonymous'}</p>
                      </div>
                    </div>
                    <div className="p-3 bg-zinc-100 dark:bg-zinc-800 rounded-2xl group-hover:bg-yellow-400 group-hover:text-black transition-all">
                      <ChevronRight className="w-5 h-5" />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-4 animate-in fade-in duration-500">
            {filteredNotes.map((note) => (
              <div 
                key={note.id} 
                onClick={() => setSelectedNote(note)}
                className="cursor-pointer bg-white dark:bg-zinc-950 p-6 rounded-[2rem] border border-zinc-200 dark:border-zinc-900 flex items-center justify-between hover:border-yellow-400 transition-all group"
              >
                <div className="flex items-center gap-8">
                  <div className="p-4 bg-zinc-50 dark:bg-zinc-900 rounded-2xl border border-zinc-100 dark:border-zinc-800 group-hover:bg-yellow-400 transition-colors">
                    <FileText className="w-8 h-8 text-yellow-500 group-hover:text-black" />
                  </div>
                  <div>
                    <h4 className="text-xl font-black uppercase tracking-tight">{note.title}</h4>
                    <p className="text-[10px] text-zinc-400 font-black uppercase tracking-[0.2em]">{note.subject} • {note.scheme} Scheme • S{note.semester} • M{note.module}</p>
                  </div>
                </div>
                <div className="flex items-center gap-12">
                   <div className="hidden lg:block text-right">
                     <p className="text-[10px] text-zinc-500 uppercase font-black tracking-widest mb-1">Contributor</p>
                     <p className="text-sm font-black">{(note as any).profiles?.name || 'Student'}</p>
                   </div>
                   <div className="px-8 py-4 bg-black dark:bg-yellow-400 text-white dark:text-black rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-all hover:scale-105 active:scale-95 shadow-xl">
                      Details
                    </div>
                </div>
              </div>
            ))}
          </div>
        )
      ) : (
        <div className="text-center py-40 bg-zinc-50 dark:bg-zinc-950 rounded-[4rem] border-4 border-dashed border-zinc-200 dark:border-zinc-900">
          <Inbox className="w-24 h-24 text-zinc-200 dark:text-zinc-800 mx-auto mb-8" />
          <h3 className="text-4xl font-black uppercase tracking-tighter">No Files Found</h3>
          <p className="text-zinc-400 max-w-sm mx-auto mt-4 font-bold uppercase tracking-widest text-xs">Try broader search terms or check back later.</p>
        </div>
      )}

      {/* Note Detail Modal */}
      {selectedNote && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 sm:p-10 animate-in fade-in duration-300">
          <div 
            className="absolute inset-0 bg-black/95 backdrop-blur-xl" 
            onClick={handleCloseModal}
          ></div>
          
          <div className="relative w-full max-w-6xl bg-white dark:bg-black rounded-[3.5rem] border border-zinc-200 dark:border-zinc-800 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 max-h-[90vh] flex flex-col">
            
            <div className="p-10 border-b border-zinc-100 dark:border-zinc-900 flex items-center justify-between bg-white dark:bg-black sticky top-0 z-10">
              <div className="flex items-center gap-8">
                <div className="bg-yellow-400 p-5 rounded-[2rem] shadow-2xl shadow-yellow-400/20">
                  <FileText className="w-12 h-12 text-black" />
                </div>
                <div>
                  <h2 className="text-4xl md:text-5xl font-black tracking-tighter text-black dark:text-white uppercase leading-none">{selectedNote.title}</h2>
                  <div className="flex items-center gap-4 mt-4">
                    <span className="text-[11px] font-black text-yellow-600 dark:text-yellow-400 uppercase tracking-[0.3em]">{selectedNote.subject}</span>
                    <span className="w-1.5 h-1.5 bg-zinc-200 dark:bg-zinc-800 rounded-full"></span>
                    <span className="text-[11px] font-black text-zinc-400 uppercase tracking-widest">{selectedNote.scheme} Scheme • S{selectedNote.semester} • M{selectedNote.module}</span>
                  </div>
                </div>
              </div>
              <button 
                onClick={handleCloseModal}
                className="p-4 rounded-3xl bg-zinc-100 dark:bg-zinc-900 text-zinc-500 hover:text-black dark:hover:text-white transition-all hover:rotate-90"
              >
                <X className="w-8 h-8" />
              </button>
            </div>

            <div className="flex-grow overflow-y-auto p-10 lg:p-20">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-20">
                <div className="lg:col-span-8 space-y-16">
                  <section>
                    <h4 className="text-[10px] font-black text-zinc-400 uppercase tracking-[0.4em] mb-8 flex items-center gap-3">
                      <Info className="w-5 h-5 text-yellow-500" /> Summary & Meta
                    </h4>
                    <p className="text-zinc-700 dark:text-zinc-300 leading-relaxed text-2xl font-bold bg-zinc-50 dark:bg-zinc-900/40 p-12 rounded-[3rem] border border-zinc-100 dark:border-zinc-800">
                      {selectedNote.description || 'Verified archive material. No extended summary available.'}
                    </p>
                  </section>

                  <section>
                    <h4 className="text-[10px] font-black text-zinc-400 uppercase tracking-[0.4em] mb-10">Related Resources</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                      {getRelatedNotes(selectedNote).map(related => (
                        <div 
                          key={related.id} 
                          onClick={() => setSelectedNote(related)}
                          className="p-8 rounded-[2.5rem] bg-zinc-50 dark:bg-zinc-900/30 border border-zinc-100 dark:border-zinc-800 hover:border-yellow-400 transition-all cursor-pointer group"
                        >
                          <p className="font-black text-xl text-black dark:text-zinc-100 uppercase tracking-tight group-hover:text-yellow-500 line-clamp-1">{related.title}</p>
                          <p className="text-[10px] font-black text-zinc-500 mt-3 uppercase tracking-widest">{related.scheme} Scheme • Module {related.module} • {related.note_type}</p>
                        </div>
                      ))}
                    </div>
                  </section>
                </div>

                <div className="lg:col-span-4 space-y-10">
                  <div className="bg-black dark:bg-yellow-400 rounded-[3rem] p-12 shadow-2xl text-white dark:text-black">
                    <p className="text-[10px] font-black uppercase tracking-[0.3em] mb-8 opacity-70">Resource Action</p>
                    <a 
                      href={selectedNote.file_url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-4 w-full py-6 bg-white dark:bg-black text-black dark:text-white rounded-3xl font-black text-lg hover:scale-105 transition-transform shadow-xl uppercase tracking-tighter"
                    >
                      <Download className="w-6 h-6" /> Download PDF
                    </a>
                    <div className="mt-6 flex items-center justify-center gap-3 text-[10px] uppercase font-black tracking-widest opacity-60">
                      <ShieldCheck className="w-4 h-4" /> Academic Verified
                    </div>
                  </div>

                  <div className="bg-zinc-50 dark:bg-zinc-900/40 rounded-[3rem] border border-zinc-100 dark:border-zinc-800 p-10">
                    <h5 className="text-[10px] font-black text-zinc-400 uppercase tracking-[0.4em] mb-10">Contributor</h5>
                    <div className="flex items-center gap-6">
                      <div className="w-16 h-16 rounded-[1.5rem] bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 flex items-center justify-center">
                        <UserIcon className="w-8 h-8 text-yellow-500" />
                      </div>
                      <div>
                        <p className="text-xl font-black text-black dark:text-white uppercase tracking-tight">{(selectedNote as any).profiles?.name || 'Academic Contributor'}</p>
                        <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mt-1">NoteHub Elite</p>
                      </div>
                    </div>
                    <div className="mt-10 pt-10 border-t border-zinc-100 dark:border-zinc-800 space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Scheme</span>
                        <span className="text-sm font-black uppercase tracking-tight">{selectedNote.scheme}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Type</span>
                        <span className="text-sm font-black uppercase tracking-tight">{selectedNote.note_type}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Added</span>
                        <span className="text-sm font-black uppercase tracking-tight">{new Date(selectedNote.created_at).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
