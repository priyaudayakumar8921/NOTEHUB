
import React, { useEffect, useState } from 'react';
import { supabase, Note, Profile } from '../lib/supabase';
import { 
  ShieldCheck, 
  Clock, 
  Check, 
  X, 
  Trash2, 
  ExternalLink,
  Users,
  FileText,
  Loader2,
  CheckCircle2,
  XCircle
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const [pendingNotes, setPendingNotes] = useState<Note[]>([]);
  const [stats, setStats] = useState({ users: 0, notes: 0, verified: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAdminData();
  }, []);

  const fetchAdminData = async () => {
    setLoading(true);
    const { data: notes, error: notesError } = await supabase
      .from('notes')
      .select('*, profiles(name, email)')
      .eq('verified', false)
      .order('created_at', { ascending: true });

    if (!notesError) setPendingNotes(notes || []);

    const { count: userCount } = await supabase.from('users').select('*', { count: 'exact', head: true });
    const { count: totalNoteCount } = await supabase.from('notes').select('*', { count: 'exact', head: true });
    const { count: verifiedCount } = await supabase.from('notes').select('*', { count: 'exact', head: true }).eq('verified', true);

    setStats({
      users: userCount || 0,
      notes: totalNoteCount || 0,
      verified: verifiedCount || 0
    });
    
    setLoading(false);
  };

  const handleVerify = async (noteId: string) => {
    const { error } = await supabase
      .from('notes')
      .update({ verified: true })
      .eq('id', noteId);
    
    if (!error) {
      setPendingNotes(prev => prev.filter(n => n.id !== noteId));
      setStats(prev => ({ ...prev, verified: prev.verified + 1 }));
    }
  };

  const handleDelete = async (noteId: string) => {
    if (confirm('Are you sure you want to reject and delete this note?')) {
      const { error } = await supabase
        .from('notes')
        .delete()
        .eq('id', noteId);
      
      if (!error) {
        setPendingNotes(prev => prev.filter(n => n.id !== noteId));
        setStats(prev => ({ ...prev, notes: prev.notes - 1 }));
      }
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-16 bg-white dark:bg-black min-h-screen">
      <div className="flex items-center gap-4 mb-16">
        <div className="p-4 bg-yellow-400 rounded-2xl shadow-xl shadow-yellow-400/20">
          <ShieldCheck className="w-10 h-10 text-black" />
        </div>
        <div>
          <h1 className="text-5xl font-black uppercase tracking-tighter">Command Center</h1>
          <p className="text-zinc-500 font-bold uppercase tracking-[0.2em] text-[10px] mt-2">Content Moderation & Analytics</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
        {[
          { icon: <Users className="w-6 h-6" />, label: "Users", value: stats.users },
          { icon: <FileText className="w-6 h-6" />, label: "Total Files", value: stats.notes },
          { icon: <CheckCircle2 className="w-6 h-6" />, label: "Verified", value: stats.verified }
        ].map((item, i) => (
          <div key={i} className="bg-zinc-50 dark:bg-zinc-900 p-10 rounded-[2.5rem] border border-zinc-200 dark:border-zinc-800 shadow-xl flex items-center gap-8">
            <div className="p-5 rounded-2xl bg-black dark:bg-yellow-400 text-white dark:text-black">
              {item.icon}
            </div>
            <div>
              <p className="text-zinc-500 text-[10px] font-black uppercase tracking-[0.2em] mb-2">{item.label}</p>
              <p className="text-4xl font-black tracking-tighter">{item.value.toLocaleString()}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white dark:bg-zinc-950 rounded-[3rem] border-2 border-zinc-100 dark:border-zinc-900 shadow-2xl overflow-hidden">
        <div className="px-10 py-8 border-b border-zinc-100 dark:border-zinc-900 flex items-center justify-between bg-zinc-50 dark:bg-zinc-900/50">
          <h2 className="text-2xl font-black uppercase tracking-tighter flex items-center gap-4">
            <Clock className="w-8 h-8 text-yellow-500" />
            Verification Queue
            <span className="ml-4 px-3 py-1 bg-yellow-400 text-black text-[10px] font-black uppercase tracking-widest rounded-full">
              {pendingNotes.length} Pending
            </span>
          </h2>
          <button onClick={fetchAdminData} className="text-zinc-400 hover:text-black dark:hover:text-white transition-colors text-[10px] font-black uppercase tracking-[0.2em]">Refresh Archive</button>
        </div>

        <div className="overflow-x-auto">
          {loading ? (
            <div className="p-32 flex justify-center">
              <Loader2 className="w-12 h-12 text-yellow-400 animate-spin" />
            </div>
          ) : pendingNotes.length > 0 ? (
            <table className="w-full text-left">
              <thead className="bg-zinc-50 dark:bg-zinc-900/80 text-zinc-500 text-[10px] uppercase font-black tracking-[0.2em]">
                <tr>
                  <th className="px-10 py-6">Asset Details</th>
                  <th className="px-10 py-6">Contributor</th>
                  <th className="px-10 py-6">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100 dark:divide-zinc-900">
                {pendingNotes.map((note) => (
                  <tr key={note.id} className="hover:bg-zinc-50/50 dark:hover:bg-zinc-900/30 transition-colors group">
                    <td className="px-10 py-8">
                      <div className="font-black text-black dark:text-white uppercase tracking-tight text-lg mb-2">{note.title}</div>
                      <div className="flex items-center gap-3">
                        <span className="text-[10px] px-3 py-1 bg-zinc-200 dark:bg-zinc-800 text-zinc-500 rounded-md font-black uppercase tracking-widest">{note.subject}</span>
                        <span className="text-[10px] px-3 py-1 bg-yellow-400/10 text-yellow-600 dark:text-yellow-400 border border-yellow-400/20 rounded-md font-black uppercase tracking-widest">S{note.semester}</span>
                      </div>
                    </td>
                    <td className="px-10 py-8">
                      <div className="font-black text-black dark:text-white uppercase tracking-tight">{(note as any).profiles?.name}</div>
                      <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">{(note as any).profiles?.email}</div>
                    </td>
                    <td className="px-10 py-8">
                      <div className="flex items-center gap-4">
                        <a 
                          href={note.file_url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="p-4 rounded-2xl bg-zinc-100 dark:bg-zinc-800 text-zinc-500 hover:bg-yellow-400 hover:text-black transition-all"
                        >
                          <ExternalLink className="w-5 h-5" />
                        </a>
                        <button 
                          onClick={() => handleVerify(note.id)}
                          className="p-4 rounded-2xl bg-black dark:bg-yellow-400 text-white dark:text-black hover:scale-105 transition-all shadow-xl"
                        >
                          <Check className="w-5 h-5" />
                        </button>
                        <button 
                          onClick={() => handleDelete(note.id)}
                          className="p-4 rounded-2xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-red-500 hover:bg-red-500 hover:text-white transition-all shadow-xl"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="p-32 text-center">
              <CheckCircle2 className="w-20 h-20 text-zinc-200 dark:text-zinc-800 mx-auto mb-6" />
              <h3 className="text-3xl font-black uppercase tracking-tighter">Queue Empty</h3>
              <p className="text-zinc-400 font-bold uppercase tracking-widest text-xs mt-2">All contributions have been processed.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
