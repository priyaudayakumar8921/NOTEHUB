
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { supabase, SchemeType } from '../lib/supabase';
import { 
  CloudUpload, 
  FileText, 
  CheckCircle, 
  AlertCircle, 
  Loader2,
  BookOpen,
  Info,
  Layers
} from 'lucide-react';

export const Upload: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const [formData, setFormData] = useState({
    title: '',
    subject: '',
    semester: '1',
    scheme: '2019' as SchemeType,
    module: '1',
    description: '',
    note_type: 'handwritten' as 'handwritten' | 'typed',
    file: null as File | null,
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 10 * 1024 * 1024) { // 10MB limit
        setError('File exceeds 10MB limit.');
        return;
      }
      setFormData({ ...formData, file });
      setError(null);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.file || !user) {
      setError('Select a resource file.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const fileExt = formData.file.name.split('.').pop();
      const fileName = `${user.id}-${Math.random()}.${fileExt}`;
      const filePath = `notes/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('notes-files')
        .upload(filePath, formData.file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('notes-files')
        .getPublicUrl(filePath);

      const { error: dbError } = await supabase.from('notes').insert({
        title: formData.title,
        subject: formData.subject,
        semester: parseInt(formData.semester),
        scheme: formData.scheme,
        module: parseInt(formData.module),
        description: formData.description,
        note_type: formData.note_type,
        file_url: publicUrl,
        uploaded_by: user.id,
        verified: false
      });

      if (dbError) throw dbError;

      setSuccess(true);
      setTimeout(() => navigate('/dashboard'), 2000);
    } catch (err: any) {
      setError(err.message || 'Transmission failed.');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-40 text-center bg-white dark:bg-black">
        <div className="bg-yellow-400 p-20 rounded-[4rem] shadow-2xl animate-in zoom-in duration-500">
          <CheckCircle className="w-24 h-24 text-black mx-auto mb-8" />
          <h2 className="text-5xl font-black uppercase tracking-tighter text-black mb-6 leading-none">Archive Updated</h2>
          <p className="text-black/70 font-bold uppercase tracking-widest text-[10px] mb-12">Review process initiated by system admin.</p>
          <div className="flex justify-center gap-4">
             <div className="w-3 h-3 bg-black rounded-full animate-bounce delay-75"></div>
             <div className="w-3 h-3 bg-black rounded-full animate-bounce delay-150"></div>
             <div className="w-3 h-3 bg-black rounded-full animate-bounce delay-300"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-20 bg-white dark:bg-black">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
        {/* Help Sidebar */}
        <div className="lg:col-span-4 space-y-8 order-2 lg:order-1">
          <div className="bg-black dark:bg-yellow-400 p-12 rounded-[3rem] text-white dark:text-black shadow-2xl">
            <Info className="w-12 h-12 mb-8 opacity-80" />
            <h3 className="text-3xl font-black uppercase tracking-tighter mb-6 leading-none">Directives</h3>
            <ul className="space-y-4 text-xs font-bold uppercase tracking-widest opacity-80">
              <li className="flex gap-3">• High Contrast Scans Only</li>
              <li className="flex gap-3">• PDF Format Preferred</li>
              <li className="flex gap-3">• Module Numbers Mandatory</li>
              <li className="flex gap-3">• Specify KTU Scheme Correctly</li>
            </ul>
          </div>
          
          <div className="bg-zinc-50 dark:bg-zinc-900 p-10 rounded-[3rem] border border-zinc-100 dark:border-zinc-800">
            <h4 className="text-xl font-black uppercase tracking-tighter mb-4 flex items-center gap-3">
              <BookOpen className="w-6 h-6 text-yellow-400" />
              Scheme Accuracy
            </h4>
            <p className="text-zinc-500 dark:text-zinc-400 text-xs font-bold leading-relaxed">
              KTU introduced the 2024 scheme with major syllabus changes. Ensure your notes match the correct scheme before uploading.
            </p>
          </div>
        </div>

        {/* Upload Form */}
        <div className="lg:col-span-8 order-1 lg:order-2">
          <div className="bg-white dark:bg-zinc-950 p-10 lg:p-16 rounded-[4rem] border-2 border-zinc-100 dark:border-zinc-900 shadow-2xl">
            <h2 className="text-4xl font-black uppercase tracking-tighter mb-12 flex items-center gap-6">
              <div className="bg-yellow-400 p-4 rounded-2xl shadow-xl shadow-yellow-400/20">
                <CloudUpload className="w-10 h-10 text-black" />
              </div>
              Contribute Data
            </h2>

            {error && (
              <div className="mb-10 p-6 bg-red-500/10 border border-red-500/20 text-red-500 rounded-[2rem] flex items-center gap-4">
                <AlertCircle className="w-6 h-6 flex-shrink-0" />
                <span className="text-[10px] font-black uppercase tracking-widest">{error}</span>
              </div>
            )}

            <form onSubmit={handleUpload} className="space-y-10">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div className="md:col-span-2">
                  <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-[0.3em] mb-4 ml-2">Archive Title</label>
                  <input 
                    type="text" 
                    required 
                    placeholder="e.g. OS PROCESS SCHEDULING NOTES"
                    className="w-full bg-zinc-50 dark:bg-black border border-zinc-200 dark:border-zinc-800 rounded-3xl px-8 py-5 outline-none focus:ring-4 focus:ring-yellow-400/20 transition-all font-bold text-sm uppercase tracking-tight"
                    value={formData.title}
                    onChange={(e) => setFormData({...formData, title: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-[0.3em] mb-4 ml-2">Subject</label>
                  <input 
                    type="text" 
                    required 
                    placeholder="e.g. OPERATING SYSTEMS"
                    className="w-full bg-zinc-50 dark:bg-black border border-zinc-200 dark:border-zinc-800 rounded-3xl px-8 py-5 outline-none focus:ring-4 focus:ring-yellow-400/20 transition-all font-bold text-sm uppercase tracking-tight"
                    value={formData.subject}
                    onChange={(e) => setFormData({...formData, subject: e.target.value})}
                  />
                </div>
                <div className="grid grid-cols-2 gap-6">
                   <div>
                    <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-[0.3em] mb-4 ml-2">Scheme</label>
                    <select 
                      className="w-full bg-zinc-50 dark:bg-black border border-zinc-200 dark:border-zinc-800 rounded-3xl px-6 py-5 outline-none focus:ring-4 focus:ring-yellow-400/20 transition-all font-black text-sm"
                      value={formData.scheme}
                      onChange={(e) => setFormData({...formData, scheme: e.target.value as SchemeType})}
                    >
                      <option value="2019">2019</option>
                      <option value="2024">2024</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-[0.3em] mb-4 ml-2">Sem</label>
                    <select 
                      className="w-full bg-zinc-50 dark:bg-black border border-zinc-200 dark:border-zinc-800 rounded-3xl px-6 py-5 outline-none focus:ring-4 focus:ring-yellow-400/20 transition-all font-black text-sm"
                      value={formData.semester}
                      onChange={(e) => setFormData({...formData, semester: e.target.value})}
                    >
                      {[1, 2, 3, 4, 5, 6, 7, 8].map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                </div>
                <div className="md:col-span-2">
                  <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-[0.3em] mb-4 ml-2">Module</label>
                  <select 
                    className="w-full bg-zinc-50 dark:bg-black border border-zinc-200 dark:border-zinc-800 rounded-3xl px-6 py-5 outline-none focus:ring-4 focus:ring-yellow-400/20 transition-all font-black text-sm"
                    value={formData.module}
                    onChange={(e) => setFormData({...formData, module: e.target.value})}
                  >
                    {[1, 2, 3, 4, 5, 6].map(m => <option key={m} value={m}>{m}</option>)}
                  </select>
                </div>
                <div className="md:col-span-2">
                  <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-[0.3em] mb-4 ml-2">Format</label>
                  <div className="flex bg-zinc-50 dark:bg-black p-2 rounded-[2rem] border border-zinc-200 dark:border-zinc-800">
                    <button 
                      type="button"
                      onClick={() => setFormData({...formData, note_type: 'handwritten'})}
                      className={`flex-1 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${formData.note_type === 'handwritten' ? 'bg-black dark:bg-yellow-400 text-white dark:text-black shadow-xl' : 'text-zinc-400'}`}
                    >
                      Handwritten
                    </button>
                    <button 
                      type="button"
                      onClick={() => setFormData({...formData, note_type: 'typed'})}
                      className={`flex-1 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${formData.note_type === 'typed' ? 'bg-black dark:bg-yellow-400 text-white dark:text-black shadow-xl' : 'text-zinc-400'}`}
                    >
                      Typed
                    </button>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-[0.3em] mb-4 ml-2">Asset Summary</label>
                <textarea 
                  rows={4}
                  className="w-full bg-zinc-50 dark:bg-black border border-zinc-200 dark:border-zinc-800 rounded-3xl px-8 py-5 outline-none focus:ring-4 focus:ring-yellow-400/20 transition-all font-bold text-sm"
                  placeholder="Key topics covered..."
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                ></textarea>
              </div>

              <div>
                <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-[0.3em] mb-4 ml-2">Resource Attachment (PDF/IMG)</label>
                <div className="relative group">
                  <input 
                    type="file" 
                    required 
                    accept=".pdf,image/*"
                    onChange={handleFileChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  />
                  <div className="border-4 border-dashed border-zinc-100 dark:border-zinc-900 rounded-[3rem] p-16 flex flex-col items-center justify-center group-hover:border-yellow-400 group-hover:bg-yellow-400/5 transition-all text-center">
                    <CloudUpload className="w-16 h-16 text-zinc-200 dark:text-zinc-800 group-hover:text-yellow-400 mb-6 transition-colors" />
                    <p className="text-zinc-500 font-black uppercase tracking-widest text-[10px]">
                      {formData.file ? formData.file.name : 'Link Local Archive'}
                    </p>
                    <p className="text-zinc-300 dark:text-zinc-600 text-[10px] mt-4 italic font-bold">MAX CAPACITY: 10MB</p>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-6 bg-black dark:bg-yellow-400 text-white dark:text-black font-black uppercase tracking-[0.2em] text-sm rounded-[2rem] transition-all hover:scale-[1.02] active:scale-95 shadow-2xl disabled:opacity-50"
              >
                {loading ? <Loader2 className="w-8 h-8 animate-spin" /> : 'Execute Submission'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
