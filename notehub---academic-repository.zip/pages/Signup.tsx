
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { UserPlus, Mail, Lock, User, Loader2, AlertCircle, Code, CheckCircle2, Inbox } from 'lucide-react';

export const Signup: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [needsVerification, setNeedsVerification] = useState(false);
  const navigate = useNavigate();

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name: name,
          }
        }
      });

      if (authError) throw authError;
      
      // If email confirmation is enabled, session will be null
      if (authData.user && !authData.session) {
        setNeedsVerification(true);
      } else if (authData.user) {
        navigate('/dashboard');
      }
    } catch (err: any) {
      setError(err.message || 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (needsVerification) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4 py-20 bg-white dark:bg-black">
        <div className="w-full max-w-md bg-zinc-50 dark:bg-zinc-900 p-12 rounded-[3rem] border border-zinc-200 dark:border-zinc-800 shadow-2xl text-center animate-in zoom-in duration-500">
          <div className="bg-yellow-400 w-24 h-24 rounded-[2rem] flex items-center justify-center mx-auto mb-10 shadow-2xl shadow-yellow-400/20 rotate-3">
            <Inbox className="w-12 h-12 text-black" />
          </div>
          <h2 className="text-4xl font-black uppercase tracking-tighter mb-4">Check Inbox</h2>
          <p className="text-zinc-500 font-bold text-sm leading-relaxed mb-10 uppercase tracking-tight">
            We've dispatched an activation link to <span className="text-black dark:text-white font-black">{email}</span>. Please verify your email to access NoteHub.
          </p>
          <div className="space-y-4">
            <Link 
              to="/login"
              className="block w-full py-5 bg-black dark:bg-yellow-400 text-white dark:text-black font-black uppercase tracking-widest text-xs rounded-2xl hover:scale-[1.02] transition-all"
            >
              Return to Login
            </Link>
            <p className="text-[10px] text-zinc-400 font-black uppercase tracking-widest pt-4">
              Didn't get the email? Check your spam folder.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-20 bg-white dark:bg-black">
      <div className="w-full max-w-md bg-zinc-50 dark:bg-zinc-900 p-10 rounded-[2.5rem] border border-zinc-200 dark:border-zinc-800 shadow-2xl">
        <div className="text-center mb-10">
          <div className="bg-black dark:bg-yellow-400 w-16 h-16 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-yellow-400/20">
            <UserPlus className="w-8 h-8 text-white dark:text-black" />
          </div>
          <h2 className="text-4xl font-black uppercase tracking-tighter text-black dark:text-white">Join Hub</h2>
          <div className="inline-flex items-center gap-1.5 mt-3 text-yellow-600 dark:text-yellow-400">
            <Code className="w-3 h-3" />
            <span className="text-[10px] font-black uppercase tracking-widest">CS Students Only</span>
          </div>
        </div>

        {error && (
          <div className="mb-8 p-5 bg-red-500/10 border border-red-500/20 text-red-500 rounded-2xl flex items-center gap-4 animate-in fade-in zoom-in duration-300">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <span className="text-xs font-black uppercase tracking-widest">{error}</span>
          </div>
        )}

        <form onSubmit={handleSignup} className="space-y-6">
          <div>
            <label className="block text-[10px] font-black text-zinc-500 dark:text-zinc-400 uppercase tracking-[0.2em] mb-3 ml-1">Full Name</label>
            <div className="relative">
              <User className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
              <input
                type="text"
                required
                className="w-full pl-14 pr-6 py-4 bg-white dark:bg-black border border-zinc-200 dark:border-zinc-800 rounded-2xl focus:ring-4 focus:ring-yellow-400/20 outline-none transition-all font-bold text-sm text-black dark:text-white"
                placeholder="Student Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-black text-zinc-500 dark:text-zinc-400 uppercase tracking-[0.2em] mb-3 ml-1">College Email</label>
            <div className="relative">
              <Mail className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
              <input
                type="email"
                required
                className="w-full pl-14 pr-6 py-4 bg-white dark:bg-black border border-zinc-200 dark:border-zinc-800 rounded-2xl focus:ring-4 focus:ring-yellow-400/20 outline-none transition-all font-bold text-sm text-black dark:text-white"
                placeholder="identity@college.edu"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-black text-zinc-500 dark:text-zinc-400 uppercase tracking-[0.2em] mb-3 ml-1">Secret Key</label>
            <div className="relative">
              <Lock className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
              <input
                type="password"
                required
                minLength={6}
                className="w-full pl-14 pr-6 py-4 bg-white dark:bg-black border border-zinc-200 dark:border-zinc-800 rounded-2xl focus:ring-4 focus:ring-yellow-400/20 outline-none transition-all font-bold text-sm text-black dark:text-white"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-5 bg-black dark:bg-yellow-400 text-white dark:text-black font-black uppercase tracking-widest text-sm rounded-2xl transition-all hover:scale-[1.02] active:scale-95 shadow-2xl flex items-center justify-center gap-3 disabled:opacity-50"
          >
            {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : 'Authorize Identity'}
          </button>
        </form>

        <p className="mt-10 text-center text-zinc-500 text-[10px] font-black uppercase tracking-widest">
          Already Enlisted?{' '}
          <Link to="/login" className="text-yellow-600 dark:text-yellow-400 hover:underline font-bold">Sign In</Link>
        </p>
      </div>
    </div>
  );
};
