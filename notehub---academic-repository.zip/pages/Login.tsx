
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { LogIn, Mail, Lock, Loader2, AlertCircle, Send, CheckCircle2 } from 'lucide-react';

export const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isUnconfirmed, setIsUnconfirmed] = useState(false);
  const [resendSuccess, setResendSuccess] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setIsUnconfirmed(false);
    setResendSuccess(false);

    try {
      const { error: authError } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (authError) {
        if (authError.message.toLowerCase().includes('email not confirmed')) {
          setIsUnconfirmed(true);
        }
        throw authError;
      }
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    setResending(true);
    try {
      const { error: resendError } = await supabase.auth.resend({
        type: 'signup',
        email: email,
      });
      if (resendError) throw resendError;
      setResendSuccess(true);
    } catch (err: any) {
      setError(err.message || 'Failed to resend confirmation');
    } finally {
      setResending(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-20 bg-white dark:bg-black">
      <div className="w-full max-w-md bg-zinc-50 dark:bg-zinc-900 p-10 rounded-[2.5rem] border border-zinc-200 dark:border-zinc-800 shadow-2xl">
        <div className="text-center mb-10">
          <div className="bg-yellow-400 w-16 h-16 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-yellow-400/20">
            <LogIn className="w-8 h-8 text-black" />
          </div>
          <h2 className="text-4xl font-black uppercase tracking-tighter">Enter Hub</h2>
          <p className="text-zinc-500 font-bold uppercase tracking-widest text-[10px] mt-3">Access your academic command center</p>
        </div>

        {error && (
          <div className={`mb-8 p-5 rounded-2xl flex flex-col gap-3 animate-in fade-in zoom-in duration-300 ${isUnconfirmed ? 'bg-amber-500/10 border border-amber-500/20 text-amber-600 dark:text-amber-400' : 'bg-red-500/10 border border-red-500/20 text-red-500'}`}>
            <div className="flex items-center gap-4">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <span className="text-[10px] font-black uppercase tracking-widest">{isUnconfirmed ? 'Activation Required' : error}</span>
            </div>
            {isUnconfirmed && (
              <div className="mt-2 pl-9 space-y-4">
                <p className="text-[10px] font-bold uppercase leading-relaxed">Your identity has not been verified. Please check your inbox for the activation link.</p>
                {!resendSuccess ? (
                  <button 
                    onClick={handleResend}
                    disabled={resending}
                    className="flex items-center gap-2 text-[10px] font-black bg-amber-500 text-white px-4 py-2 rounded-lg hover:scale-105 transition-all disabled:opacity-50"
                  >
                    {resending ? <Loader2 className="w-3 h-3 animate-spin" /> : <Send className="w-3 h-3" />}
                    Resend Verification
                  </button>
                ) : (
                  <div className="flex items-center gap-2 text-[10px] font-black text-green-500">
                    <CheckCircle2 className="w-3 h-3" /> Link Dispatched
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] mb-3 ml-1">Email Identity</label>
            <div className="relative">
              <Mail className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
              <input
                type="email"
                required
                className="w-full pl-14 pr-6 py-4 bg-white dark:bg-black border border-zinc-200 dark:border-zinc-800 rounded-2xl focus:ring-4 focus:ring-yellow-400/20 outline-none transition-all font-bold text-sm"
                placeholder="identity@ktu.edu"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] mb-3 ml-1">Secret Key</label>
            <div className="relative">
              <Lock className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
              <input
                type="password"
                required
                className="w-full pl-14 pr-6 py-4 bg-white dark:bg-black border border-zinc-200 dark:border-zinc-800 rounded-2xl focus:ring-4 focus:ring-yellow-400/20 outline-none transition-all font-bold text-sm"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-5 bg-black dark:bg-yellow-400 text-white dark:text-black font-black uppercase tracking-widest text-sm rounded-2xl transition-all hover:scale-[1.02] active:scale-95 shadow-2xl flex items-center justify-center gap-3 disabled:opacity-50"
          >
            {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : 'Authorize'}
          </button>
        </form>

        <p className="mt-10 text-center text-zinc-500 text-[10px] font-black uppercase tracking-widest">
          New Explorer?{' '}
          <Link to="/signup" className="text-yellow-600 dark:text-yellow-400 hover:underline">Register Identity</Link>
        </p>
      </div>
    </div>
  );
};
