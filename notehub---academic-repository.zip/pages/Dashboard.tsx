
import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase, Note } from '../lib/supabase';
import { Link } from 'react-router-dom';
import { 
  PlusCircle, 
  FileCheck, 
  Clock, 
  Download,
  AlertTriangle,
  ChevronRight,
  TrendingUp,
  Award,
  Loader2
} from 'lucide-react';

export const Dashboard: React.FC = () => {
  const { profile, user } = useAuth();
  const [myNotes, setMyNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchMyNotes();
    }
  }, [user]);

  const fetchMyNotes = async () => {
    const { data, error } = await supabase
      .from('notes')
      .select('*')
      .eq('uploaded_by', user?.id)
      .order('created_at', { ascending: false });

    if (!error) setMyNotes(data || []);
    setLoading(false);
  };

  const pendingCount = myNotes.filter(n => !n.verified).length;
  const verifiedCount = myNotes.filter(n => n.verified).length;

  return (
    <div className="max-w-7xl mx-auto px-4 py-20 bg-white dark:bg-black">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-10 mb-16">
        <div>
          <h1 className="text-5xl md:text-6xl font-black uppercase tracking-tighter">Welcome, {profile?.name?.split(' ')[0]}</h1>
          <p className="text-zinc-500 font-bold uppercase tracking-[0.2em] text-xs mt-4">Command Center / Contributions</p>
        </div>
        <Link 
          to="/upload" 
          className="bg-yellow-400 hover:bg-yellow-300 text-black px-10 py-5 rounded-[2rem] font-black uppercase tracking-widest text-sm flex items-center gap-3 transition-all shadow-2xl shadow-yellow-400/10 hover:scale-105"
        >
          <PlusCircle className="w-5 h-5" />
          Add Resource
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
        <div className="p-10 rounded-[3rem] bg-zinc-50 dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800">
          <div className="flex items-center gap-5 mb-6">
            <div className="p-4 rounded-2xl bg-black dark:bg-yellow-400 text-white dark:text-black">
              <FileCheck className="w-8 h-8" />
            </div>
            <span className="text-zinc-500 font-black uppercase tracking-widest text-[10px]">Archives</span>
          </div>
          <div className="text-6xl font-black tracking-tighter">{myNotes.length}</div>
        </div>
        <div className="p-10 rounded-[3rem] bg-zinc-50 dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800">
          <div className="flex items-center gap-5 mb-6">
            <div className="p-4 rounded-2xl bg-black dark:bg-yellow-400 text-white dark:text-black">
              <Award className="w-8 h-8" />
            </div>
            <span className="text-zinc-500 font-black uppercase tracking-widest text-[10px]">Verified</span>
          </div>
          <div className="text-6xl font-black tracking-tighter text-yellow-500">{verifiedCount}</div>
        </div>
        <div className="p-10 rounded-[3rem] bg-zinc-50 dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800">
          <div className="flex items-center gap-5 mb-6">
            <div className="p-4 rounded-2xl bg-black dark:bg-yellow-400 text-white dark:text-black">
              <Clock className="w-8 h-8" />
            </div>
            <span className="text-zinc-500 font-black uppercase tracking-widest text-[10px]">In Review</span>
          </div>
          <div className="text-6xl font-black tracking-tighter">{pendingCount}</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Recent Uploads */}
        <div className="lg:col-span-8 space-y-8">
          <div className="flex items-center justify-between px-2">
            <h2 className="text-2xl font-black uppercase tracking-tighter flex items-center gap-3">
              <Clock className="w-6 h-6 text-yellow-400" />
              Activity Log
            </h2>
            <Link to="/notes" className="text-zinc-400 text-[10px] font-black uppercase tracking-widest hover:text-yellow-500 flex items-center gap-2">
              View Global <ChevronRight className="w-4 h-4" />
            </Link>
          </div>

          {loading ? (
            <div className="flex justify-center p-20">
              <Loader2 className="w-12 h-12 animate-spin text-yellow-400" />
            </div>
          ) : myNotes.length > 0 ? (
            <div className="space-y-4">
              {myNotes.map((note) => (
                <div key={note.id} className="p-6 rounded-[2rem] bg-zinc-50 dark:bg-zinc-900/50 border border-zinc-100 dark:border-zinc-800 flex items-center justify-between group hover:border-yellow-400 transition-all">
                  <div className="flex items-center gap-6">
                    <div className={`p-4 rounded-2xl ${note.verified ? 'bg-black dark:bg-yellow-400 text-white dark:text-black' : 'bg-zinc-200 dark:bg-zinc-800 text-zinc-500'}`}>
                      {note.verified ? <FileCheck className="w-6 h-6" /> : <Clock className="w-6 h-6" />}
                    </div>
                    <div>
                      <h4 className="text-lg font-black uppercase tracking-tight">{note.title}</h4>
                      <p className="text-[10px] text-zinc-500 font-black uppercase tracking-widest">{note.subject} • Sem {note.semester}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    {!note.verified && (
                      <span className="text-[10px] px-3 py-1.5 rounded-full bg-yellow-400/10 text-yellow-600 dark:text-yellow-400 border border-yellow-400/20 font-black uppercase tracking-widest">Pending</span>
                    )}
                    <a 
                      href={note.file_url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="p-4 rounded-2xl bg-white dark:bg-black border border-zinc-200 dark:border-zinc-800 text-zinc-500 hover:bg-yellow-400 hover:text-black hover:border-yellow-400 transition-all"
                    >
                      <Download className="w-5 h-5" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-zinc-50 dark:bg-zinc-900/30 rounded-[3rem] border-2 border-dashed border-zinc-200 dark:border-zinc-800">
              <AlertTriangle className="w-16 h-16 text-zinc-300 dark:text-zinc-800 mx-auto mb-6" />
              <p className="text-zinc-400 font-bold uppercase tracking-widest text-[10px]">No contributions recorded yet.</p>
              <Link to="/upload" className="text-yellow-500 mt-4 block font-black uppercase tracking-widest text-[10px] hover:underline">Launch First Upload</Link>
            </div>
          )}
        </div>

        {/* Gamification/Sidebar */}
        <div className="lg:col-span-4 space-y-8">
          <div className="p-10 rounded-[3rem] bg-black dark:bg-yellow-400 text-white dark:text-black shadow-2xl relative overflow-hidden">
            <Award className="w-12 h-12 mb-6 opacity-80" />
            <h3 className="text-3xl font-black uppercase tracking-tighter mb-4 leading-none">NoteHub Elite</h3>
            <p className="text-white/60 dark:text-black/60 text-xs font-bold leading-relaxed mb-8">
              Contribute 5 verified resources to unlock "Contributor Status" and premium profile themes.
            </p>
            <div className="w-full bg-white/10 dark:bg-black/10 rounded-full h-3 mb-4">
              <div className="bg-white dark:bg-black h-3 rounded-full transition-all duration-1000" style={{ width: `${Math.min((verifiedCount / 5) * 100, 100)}%` }}></div>
            </div>
            <div className="text-[10px] font-black uppercase tracking-widest text-right">{verifiedCount}/5 Resources</div>
          </div>

          <div className="p-10 rounded-[3rem] bg-zinc-50 dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800">
            <h3 className="text-xl font-black uppercase tracking-tighter mb-6 flex items-center gap-3">
              <TrendingUp className="w-6 h-6 text-yellow-400" />
              System Log
            </h3>
            <p className="text-zinc-500 dark:text-zinc-400 text-xs font-bold leading-relaxed">
              V3.1 is live. High-contrast yellow theme implemented for better clarity in late-night study sessions.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
