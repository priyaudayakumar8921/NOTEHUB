
import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, ShieldCheck, Download, Star, ArrowRight, Code } from 'lucide-react';

export const Home: React.FC = () => {
  return (
    <div className="relative overflow-hidden bg-white dark:bg-black">
      {/* Background Accent */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[500px] bg-yellow-400/10 dark:bg-yellow-400/5 blur-[120px] rounded-full -z-10"></div>
      
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 pt-24 pb-32 text-center">
        <div className="flex flex-col items-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-black dark:bg-yellow-400/20 border border-black dark:border-yellow-400/20 text-white dark:text-yellow-400 text-[10px] font-black uppercase tracking-[0.2em] mb-8">
            <Code className="w-3 h-3" />
            CS EXCLUSIVE PLATFORM
          </div>
          
          <h1 className="text-6xl md:text-8xl font-black mb-8 leading-[0.9] tracking-tighter text-black dark:text-white">
            THE <span className="text-yellow-400">OPEN</span> <br /> 
            ARCHIVE FOR <br />
            <span className="bg-black dark:bg-yellow-400 text-white dark:text-black px-4 inline-block mt-2">ENGINEERS</span>
          </h1>
          
          <p className="text-lg md:text-xl text-zinc-500 dark:text-zinc-400 max-w-xl mx-auto mb-12 font-medium">
            Verified handwritten notes, typed summaries, and module guides. Strictly limited to <span className="text-black dark:text-white font-bold">KTU Computer Science</span> 2019 & 2024 schemes.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full max-w-md mx-auto">
            <Link 
              to="/notes" 
              className="w-full px-10 py-5 bg-black dark:bg-yellow-400 text-white dark:text-black rounded-2xl font-black text-lg transition-all hover:scale-105 active:scale-95 shadow-2xl shadow-yellow-400/20 flex items-center justify-center gap-2"
            >
              Explore CS Library <ArrowRight className="w-5 h-5" />
            </Link>
            <Link 
              to="/signup" 
              className="w-full px-10 py-5 bg-zinc-100 dark:bg-zinc-900 text-black dark:text-white rounded-2xl font-black text-lg transition-all border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-800"
            >
              Join Hub
            </Link>
          </div>
        </div>
      </section>

      {/* Stats/Features */}
      <section className="bg-zinc-50 dark:bg-zinc-950 py-24 border-y border-zinc-100 dark:border-zinc-900">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { icon: <BookOpen className="w-8 h-8 text-black dark:text-yellow-400" />, title: "Syllabus Centric", desc: "Purely CS-focused resources mapping 1:1 with KTU syllabus." },
              { icon: <ShieldCheck className="w-8 h-8 text-black dark:text-yellow-400" />, title: "CS Peer Verified", desc: "Notes audited by senior Computer Science students." },
              { icon: <Star className="w-8 h-8 text-black dark:text-yellow-400" />, title: "Code Focused", desc: "Includes algorithm breakdowns and coding logic." },
              { icon: <Download className="w-8 h-8 text-black dark:text-yellow-400" />, title: "Zero Filler", desc: "No generic content. Only high-yield CS material." }
            ].map((feature, i) => (
              <div key={i} className="p-10 rounded-3xl bg-white dark:bg-black border border-zinc-200 dark:border-zinc-800 group hover:border-yellow-400 transition-all">
                <div className="mb-6 group-hover:scale-110 transition-transform">{feature.icon}</div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-zinc-500 dark:text-zinc-500 text-sm leading-relaxed font-medium">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-4 py-32">
        <div className="p-12 md:p-20 rounded-[3rem] bg-yellow-400 dark:bg-yellow-400 relative overflow-hidden flex flex-col items-center text-center">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-white/20 to-transparent pointer-events-none"></div>
          <div className="relative z-10">
            <h2 className="text-4xl md:text-6xl font-black text-black mb-8 tracking-tighter uppercase">Share your algorithm.</h2>
            <p className="text-black/70 mb-12 text-lg md:text-xl max-w-xl mx-auto font-bold leading-tight">
              Join the elite network of CS students. Upload your handwritten logic and typed summaries today.
            </p>
            <Link 
              to="/upload" 
              className="px-12 py-5 bg-black text-white rounded-2xl font-black text-xl hover:scale-105 active:scale-95 transition-all inline-block shadow-2xl"
            >
              Start Uploading
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};
