
import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase, Profile } from '../lib/supabase';
import { User } from '@supabase/supabase-js';
import { WifiOff, RefreshCcw, Key, ShieldAlert, CheckCircle2 } from 'lucide-react';

interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  connectionError: boolean;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children?: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [connectionError, setConnectionError] = useState(false);

  useEffect(() => {
    const initializeAuth = async () => {
      try {
        // Clear any lingering session fragments from URL if they exist
        if (window.location.hash.includes('access_token')) {
          console.log('Detecting auth callback...');
        }

        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) throw error;

        const currentUser = session?.user ?? null;
        setUser(currentUser);
        
        if (currentUser) {
          await fetchProfile(currentUser.id);
        } else {
          setLoading(false);
        }
      } catch (err: any) {
        console.error('Auth initialization error:', err);
        if (err.message?.includes('fetch') || err.message?.includes('NetworkError') || !err.status) {
          setConnectionError(true);
        }
        setLoading(false);
      }
    };

    initializeAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      const currentUser = session?.user ?? null;
      setUser(currentUser);
      
      if (event === 'SIGNED_IN' || event === 'USER_UPDATED') {
        if (currentUser) {
          await fetchProfile(currentUser.id);
        }
      } else if (event === 'SIGNED_OUT') {
        setProfile(null);
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchProfile = async (userId: string, retries = 3) => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .single();
      
      if (error) {
        // If profile isn't found, it might be the trigger lagging. Retry.
        if (retries > 0) {
          setTimeout(() => fetchProfile(userId, retries - 1), 2000);
          return;
        }
        throw error;
      }
      setProfile(data);
    } catch (err) {
      console.error('Error fetching profile:', err);
    } finally {
      setLoading(false);
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  if (connectionError) {
    return (
      <div className="min-h-screen bg-white dark:bg-black flex items-center justify-center p-6">
        <div className="max-w-xl w-full bg-zinc-50 dark:bg-zinc-900 p-10 md:p-16 rounded-[3.5rem] border border-zinc-200 dark:border-zinc-800 shadow-2xl">
          <div className="bg-red-500/10 w-24 h-24 rounded-[2rem] flex items-center justify-center mx-auto mb-10 border border-red-500/20">
            <WifiOff className="w-10 h-10 text-red-500" />
          </div>
          <h2 className="text-4xl font-black text-black dark:text-white uppercase tracking-tighter text-center mb-4">Link Failed</h2>
          <p className="text-zinc-500 font-bold text-center text-sm uppercase tracking-tight mb-12">The app cannot reach your Supabase Project.</p>
          <div className="space-y-6 mb-12">
            <div className="flex gap-5 p-6 bg-white dark:bg-black rounded-3xl border border-zinc-200 dark:border-zinc-800">
              <Key className="w-6 h-6 text-yellow-500 flex-shrink-0" />
              <div>
                <p className="text-[10px] font-black uppercase tracking-widest text-zinc-400 mb-1">Check 1: API Key</p>
                <p className="text-xs font-bold text-black dark:text-white leading-relaxed">Ensure your key starts with <code className="bg-zinc-100 dark:bg-zinc-800 px-1 rounded">eyJ...</code>.</p>
              </div>
            </div>
          </div>
          <button 
            onClick={() => window.location.reload()}
            className="w-full py-6 bg-black dark:bg-yellow-400 text-white dark:text-black font-black uppercase tracking-[0.2em] text-sm rounded-3xl flex items-center justify-center gap-4 hover:scale-[1.02] transition-all"
          >
            <RefreshCcw className="w-5 h-5" /> Retry Connection
          </button>
        </div>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ user, profile, loading, connectionError, signOut }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
