
import React, { useEffect, useState } from 'react';
import { FileText } from 'lucide-react';

export const SplashScreen: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [isFadingOut, setIsFadingOut] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsFadingOut(true);
      setTimeout(() => {
        setIsVisible(false);
        onComplete();
      }, 800); // Wait for fade animation
    }, 2500); // Display time

    return () => clearTimeout(timer);
  }, [onComplete]);

  if (!isVisible) return null;

  return (
    <div 
      className={`fixed inset-0 z-[1000] flex flex-col items-center justify-center bg-black transition-opacity duration-700 ${
        isFadingOut ? 'opacity-0' : 'opacity-100'
      }`}
    >
      <div className="relative flex flex-col items-center animate-in zoom-in-95 fade-in duration-1000">
        <div className="mb-8 p-4 bg-yellow-400 rounded-[2rem] shadow-[0_0_50px_rgba(250,204,21,0.3)] animate-bounce">
          <FileText className="w-16 h-16 text-black" />
        </div>
        
        <h1 className="text-7xl md:text-9xl font-black text-yellow-400 tracking-tighter uppercase leading-none text-center">
          NOTEHUB
        </h1>
        
        <div className="mt-6 flex flex-col items-center gap-4">
          <div className="h-1 w-24 bg-yellow-400/20 rounded-full overflow-hidden">
            <div className="h-full bg-yellow-400 animate-progress origin-left"></div>
          </div>
          <p className="text-zinc-500 font-black uppercase tracking-[0.4em] text-xs md:text-sm text-center">
            Open Archive for <span className="text-zinc-100">CS Engineers</span>
          </p>
        </div>
      </div>

      <style>{`
        @keyframes progress {
          0% { transform: scaleX(0); }
          100% { transform: scaleX(1); }
        }
        .animate-progress {
          animation: progress 2.5s ease-in-out forwards;
        }
      `}</style>
    </div>
  );
};
