
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ChatBot } from './ChatBot';
import { 
  BookOpen, 
  LayoutDashboard, 
  Upload as UploadIcon, 
  User as UserIcon, 
  Settings, 
  LogOut,
  Menu,
  X,
  FileText,
  Sun,
  Moon
} from 'lucide-react';

export const Layout: React.FC<{ children?: React.ReactNode }> = ({ children }) => {
  const { user, profile, signOut } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>(
    (localStorage.getItem('theme') as 'light' | 'dark') || 'dark'
  );
  const location = useLocation();

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');

  const navItems = [
    { label: 'Explore', path: '/notes', icon: <BookOpen className="w-5 h-5" /> },
    { label: 'Dashboard', path: '/dashboard', icon: <LayoutDashboard className="w-5 h-5" />, protected: true },
    { label: 'Upload', path: '/upload', icon: <UploadIcon className="w-5 h-5" />, protected: true },
    { label: 'Profile', path: '/profile', icon: <UserIcon className="w-5 h-5" />, protected: true },
  ];

  if (profile?.role === 'admin') {
    navItems.push({ label: 'Admin', path: '/admin', icon: <Settings className="w-5 h-5" />, protected: true });
  }

  const filteredNavItems = navItems.filter(item => !item.protected || user);

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-black text-black dark:text-white transition-colors duration-300">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-white/90 dark:bg-black/90 backdrop-blur-md border-b border-zinc-200 dark:border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="bg-yellow-400 p-1.5 rounded-lg group-hover:bg-yellow-300 transition-colors">
                <FileText className="w-6 h-6 text-black" />
              </div>
              <span className="text-xl font-bold tracking-tight">NoteHub</span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-1">
              {filteredNavItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                    location.pathname === item.path 
                      ? 'bg-yellow-400/20 text-yellow-600 dark:text-yellow-400 font-bold' 
                      : 'hover:bg-zinc-100 dark:hover:bg-zinc-900 text-zinc-500 dark:text-zinc-400 hover:text-black dark:hover:text-white'
                  }`}
                >
                  {item.icon}
                  <span className="text-sm font-medium">{item.label}</span>
                </Link>
              ))}
              
              <div className="h-6 w-px bg-zinc-200 dark:bg-zinc-800 mx-2"></div>

              <button 
                onClick={toggleTheme}
                className="p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-900 text-zinc-500 transition-colors"
                aria-label="Toggle Theme"
              >
                {theme === 'light' ? <Moon className="w-5 h-5 text-zinc-800" /> : <Sun className="w-5 h-5 text-yellow-400" />}
              </button>

              {user ? (
                <button
                  onClick={() => signOut()}
                  className="ml-2 flex items-center gap-2 px-4 py-2 rounded-lg text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/20 transition-all font-bold text-sm"
                >
                  <LogOut className="w-4 h-4" />
                  Logout
                </button>
              ) : (
                <Link
                  to="/login"
                  className="ml-2 px-5 py-2 rounded-lg bg-black dark:bg-yellow-400 text-white dark:text-black text-sm font-bold transition-all hover:opacity-90"
                >
                  Login
                </Link>
              )}
            </div>

            {/* Mobile Toggle */}
            <div className="md:hidden flex items-center gap-2">
              <button 
                onClick={toggleTheme}
                className="p-2 text-zinc-500"
              >
                {theme === 'light' ? <Moon className="w-5 h-5 text-zinc-800" /> : <Sun className="w-5 h-5 text-yellow-400" />}
              </button>
              <button 
                className="p-2 text-zinc-500"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white dark:bg-black border-b border-zinc-200 dark:border-zinc-800 p-4 space-y-2 animate-in slide-in-from-top-4 duration-300">
            {filteredNavItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setIsMobileMenuOpen(false)}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl font-bold ${
                  location.pathname === item.path 
                    ? 'bg-yellow-400 text-black' 
                    : 'text-zinc-500'
                }`}
              >
                {item.icon}
                {item.label}
              </Link>
            ))}
            {user ? (
              <button
                onClick={() => { signOut(); setIsMobileMenuOpen(false); }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-500 font-bold"
              >
                <LogOut className="w-5 h-5" />
                Logout
              </button>
            ) : (
              <Link
                to="/login"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block w-full text-center py-4 rounded-xl bg-yellow-400 text-black font-bold"
              >
                Login
              </Link>
            )}
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* Persistent ChatBot */}
      <ChatBot />

      {/* Footer */}
      <footer className="bg-zinc-50 dark:bg-zinc-950 border-t border-zinc-200 dark:border-zinc-800 py-16 mt-auto transition-colors">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-6">
            <div className="bg-black dark:bg-yellow-400 p-1 rounded">
              <FileText className="w-5 h-5 text-white dark:text-black" />
            </div>
            <span className="text-xl font-black">NoteHub</span>
          </div>
          <p className="text-zinc-500 dark:text-zinc-400 text-sm max-w-sm mx-auto font-medium leading-relaxed">
            The community-driven academic archive for Computer Science students.
          </p>
          <div className="mt-12 flex justify-center gap-6 text-zinc-400 text-sm">
             <Link to="/notes" className="hover:text-yellow-500 transition-colors">Explore</Link>
             <Link to="/upload" className="hover:text-yellow-500 transition-colors">Upload</Link>
             <Link to="/profile" className="hover:text-yellow-500 transition-colors">Support</Link>
          </div>
          <div className="mt-12 pt-8 border-t border-zinc-100 dark:border-zinc-900 text-zinc-400 dark:text-zinc-600 text-[10px] font-bold uppercase tracking-widest">
            © {new Date().getFullYear()} NoteHub • Built for Students
          </div>
        </div>
      </footer>
    </div>
  );
};