
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  MessageSquare, 
  X, 
  Send, 
  Sparkles, 
  Loader2, 
  ChevronDown,
  BookOpen,
  AlertCircle,
  Zap,
  ShieldAlert
} from 'lucide-react';

export const ChatBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'ai'; text: string }[]>([
    { role: 'ai', text: 'CS ARCHIVE ASSISTANT ONLINE. I am strictly limited to Computer Science academics. Specify your CS Subject Code, Semester, and Scheme.' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const responseStream = await ai.models.generateContentStream({
        model: "gemini-3-flash-preview",
        contents: [...messages, { role: 'user', text: userMessage }].map(m => ({
          role: m.role === 'user' ? 'user' : 'model',
          parts: [{ text: m.text }]
        })),
        config: {
          systemInstruction: `You are NoteHub AI, a specialist academic moderator for KTU (Kerala Technological University) COMPUTER SCIENCE students ONLY. 
          
          STRICT DOMAIN ENFORCEMENT:
          1. You ONLY answer questions related to Computer Science (CS) and IT subjects.
          2. If a user asks about Mechanical, Civil, Electrical, or any non-CS field, POLITELY but FIRMLY state: "I am a specialized CS Assistant. I do not provide data for other branches."
          3. If the question is non-academic, redirect them back to CS exam preparation.

          MANDATORY SCHEME HANDLING:
          1. KTU has two active schemes: 2019 and 2024.
          2. Portions and course codes vary significantly between schemes.
          
          RULES FOR RESPONSE FORMATTING:
          1. ALWAYS use a highly structured, point-wise layout.
          2. Use **Bold All-Caps Headers** for Modules.
          3. Use Bullet Points (•) for individual topics.
          4. Highlight "SURE-SHOT" topics with "!!!" or "★".
          
          Tone: Authoritative, helpful, and strictly engineering-focused (CS specifically).`,
        }
      });

      let fullText = "";
      setMessages(prev => [...prev, { role: 'ai', text: "" }]);
      
      for await (const chunk of responseStream) {
        const chunkText = chunk.text || "";
        fullText += chunkText;
        setMessages(prev => {
          const newMessages = [...prev];
          newMessages[newMessages.length - 1].text = fullText;
          return newMessages;
        });
      }
    } catch (error) {
      console.error("AI Error:", error);
      setMessages(prev => [...prev, { role: 'ai', text: "CRITICAL ERROR: Connection to CS Intelligence lost." }]);
    } finally {
      setIsLoading(false);
    }
  };

  const formatMessage = (text: string) => {
    return text.split('\n').map((line, i) => {
      if (line.trim().startsWith('•') || line.trim().startsWith('*')) {
        return <div key={i} className="ml-4 mb-1 flex gap-2"><span className="text-yellow-500">•</span> {line.replace(/^[•*]\s*/, '')}</div>;
      }
      if (line.includes('**')) {
        const parts = line.split('**');
        return (
          <p key={i} className="mb-2">
            {parts.map((part, index) => index % 2 === 1 ? <strong key={index} className="text-yellow-600 dark:text-yellow-400 uppercase tracking-tighter">{part}</strong> : part)}
          </p>
        );
      }
      return <p key={i} className="mb-2 leading-relaxed">{line}</p>;
    });
  };

  return (
    <div className="fixed bottom-4 right-4 z-[100] font-sans sm:bottom-6 sm:right-6 w-[calc(100%-32px)] sm:w-auto">
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="group float-right relative flex h-16 w-16 items-center justify-center rounded-2xl bg-yellow-400 text-black shadow-2xl transition-all hover:scale-110 active:scale-95"
        >
          <div className="absolute -top-1 -right-1 h-4 w-4 animate-ping rounded-full bg-yellow-400 opacity-75"></div>
          <Zap className="h-7 w-7 transition-transform group-hover:rotate-12 fill-black" />
        </button>
      )}

      {isOpen && (
        <div className="flex h-[80vh] max-h-[650px] w-full flex-col overflow-hidden rounded-[2.5rem] border border-zinc-200 bg-white shadow-[0_32px_64px_-12px_rgba(0,0,0,0.2)] transition-all dark:border-zinc-800 dark:bg-black animate-in slide-in-from-bottom-10 fade-in duration-300 sm:w-[420px]">
          <div className="flex items-center justify-between border-b border-zinc-100 bg-black dark:bg-yellow-400 px-6 py-4 dark:border-zinc-900 sm:px-8 sm:py-6">
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-yellow-400 dark:bg-black p-2 text-black dark:text-yellow-400">
                <ShieldAlert className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-sm font-black uppercase tracking-tighter text-white dark:text-black">CS Engine AI</h3>
                <div className="flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse"></span>
                  <span className="text-[10px] font-black uppercase tracking-widest text-white/60 dark:text-black/60">Strict Domain Mode</span>
                </div>
              </div>
            </div>
            <button 
              onClick={() => setIsOpen(false)}
              className="rounded-xl p-2 text-white dark:text-black hover:bg-white/10 dark:hover:bg-black/10 transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          <div 
            ref={scrollRef}
            className="flex-grow overflow-y-auto p-6 space-y-6 scroll-smooth bg-zinc-50 dark:bg-black sm:p-8"
          >
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2 duration-300`}>
                <div className={`max-w-[90%] rounded-[1.5rem] p-4 text-[13px] font-bold shadow-sm sm:p-5 ${
                  msg.role === 'user' 
                    ? 'bg-black text-white dark:bg-zinc-800 dark:text-white rounded-br-none' 
                    : 'bg-white text-zinc-800 dark:bg-zinc-900 dark:text-zinc-100 border border-zinc-200 dark:border-zinc-800 rounded-bl-none'
                }`}>
                  {msg.role === 'ai' ? formatMessage(msg.text) : msg.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white dark:bg-zinc-900 rounded-2xl p-4 border border-zinc-200 dark:border-zinc-800">
                  <Loader2 className="h-5 w-5 animate-spin text-yellow-500" />
                </div>
              </div>
            )}
          </div>

          <div className="flex gap-2 px-6 py-3 bg-zinc-50 dark:bg-zinc-950 overflow-x-auto no-scrollbar border-t border-zinc-100 dark:border-zinc-900">
            {["2024 CS Topics", "S3 OS Portions", "Study Plan DS"].map(query => (
              <button 
                key={query}
                onClick={() => setInput(query)}
                className="whitespace-nowrap rounded-full bg-white dark:bg-black px-4 py-2 text-[10px] font-black uppercase tracking-widest text-zinc-500 border border-zinc-200 dark:border-zinc-800 hover:border-yellow-400 hover:text-black dark:hover:text-yellow-400 transition-all shadow-sm"
              >
                {query}
              </button>
            ))}
          </div>

          <div className="p-4 bg-white dark:bg-black border-t border-zinc-100 dark:border-zinc-900 sm:p-6">
            <div className="relative flex items-center">
              <input
                type="text"
                placeholder="Ask CS Portions..."
                className="w-full rounded-2xl border-2 border-zinc-100 bg-zinc-50 px-6 py-4 pr-16 text-sm font-bold outline-none transition-all focus:border-yellow-400 focus:bg-white dark:border-zinc-800 dark:bg-zinc-900 dark:text-white dark:focus:border-yellow-400"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              />
              <button 
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                className="absolute right-2 rounded-xl bg-black p-3 text-white transition-all hover:scale-105 active:scale-95 disabled:opacity-50 dark:bg-yellow-400 dark:text-black"
              >
                <Send className="h-5 w-5" />
              </button>
            </div>
            <p className="mt-4 text-center text-[9px] font-black uppercase tracking-[0.2em] text-zinc-400">
              STRICTLY COMPUTER SCIENCE • NOTEHUB CORE
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
