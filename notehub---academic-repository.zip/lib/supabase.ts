
import { createClient } from '@supabase/supabase-js';

// 1. YOUR PROJECT URL
const supabaseUrl = 'https://nvlszibpnmyeugwluazt.supabase.co';

// 2. YOUR ANON KEY 
// IMPORTANT: This must start with 'eyJ...'. 
// Find it in: Supabase Dashboard > Settings > API > anon public
const supabaseAnonKey = 'sb_publishable_WnDl2huQb6Al8yqxl0CIlg_dXIYwOcm'; 

// WARNING: The key above (sb_publishable...) is likely incorrect.
// If you see 'Failed to Fetch', please replace it with the 'eyJ...' key from your dashboard.

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true
  }
});

export type NoteType = 'handwritten' | 'typed';
export type SchemeType = '2019' | '2024';

export interface Profile {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'admin';
  created_at: string;
}

export interface Note {
  id: string;
  title: string;
  subject: string;
  semester: number;
  scheme: SchemeType;
  module: number;
  description: string;
  note_type: NoteType;
  file_url: string;
  uploaded_by: string;
  verified: boolean;
  created_at: string;
  profiles?: Profile;
}

export interface Rating {
  id: string;
  note_id: string;
  user_id: string;
  rating: number;
}
